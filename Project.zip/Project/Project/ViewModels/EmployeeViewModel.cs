﻿using Project.DataAccess;
using Project.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace Project.ViewModels
{
    public class EmployeeViewModel
    {

        private ICommand _saveCommand;
        private ICommand _resetCommand;
        private ICommand _editCommand;
        private ICommand _deleteCommand;
        private EmployeeRepository _repository;
        private Employee _employeeEntity = null;
        public EmployeeRecord EmployeeRecord { get; set; }
        public FirmEntities FirmEntities { get; set; }

        public ICommand ResetCommand
        {
            get
            {
                if (_resetCommand == null)
                {
                    _resetCommand = new RelayCommand(param => ResetData(), null);
                }
                return _resetCommand;
            }
        }

        public ICommand SaveCommand
        {
            get
            {
                if (_saveCommand == null)
                    _saveCommand = new RelayCommand(param => SaveData(), null);

                return _saveCommand;
            }
        }

        public ICommand EditCommand
        {
            get
            {
                if (_editCommand == null)
                    _editCommand = new RelayCommand(param => EditData((int)param), null);

                return _editCommand;
            }
        }

        public ICommand DeleteCommand
        {
            get
            {
                if (_deleteCommand == null)
                    _deleteCommand = new RelayCommand(param => DeleteEmployee((int)param), null);

                return _deleteCommand;
            }
        }

        public EmployeeViewModel()
        {
            _employeeEntity = new Employee();
            _repository = new EmployeeRepository();
            EmployeeRecord = new EmployeeRecord();
            GetAll();
        }

        public void ResetData()
        {
            EmployeeRecord.Id = 0;
            EmployeeRecord.Name = string.Empty;
            EmployeeRecord.LastName = string.Empty;
            EmployeeRecord.DateOfBirth = DateTime.Now;
            EmployeeRecord.Jmbg = 0;
            EmployeeRecord.Address = string.Empty;
            EmployeeRecord.Email = string.Empty;
            EmployeeRecord.PhoneNumber = 0;
        }

        public void DeleteEmployee(int id)
        {
            if (MessageBox.Show("Confirm delete of this record?", "Employee", MessageBoxButton.YesNo)
                == MessageBoxResult.Yes)
            {
                try
                {
                    _repository.RemoveEmployee(id);
                    MessageBox.Show("Record successfully deleted.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occured while saving. " + ex.InnerException);
                }
                finally
                {
                    GetAll();
                }
            }
        }

        public void SaveData()
        {
            if (EmployeeRecord != null)
            {
                _employeeEntity.Name = EmployeeRecord.Name;
                _employeeEntity.LastName = EmployeeRecord.LastName;
                _employeeEntity.DateOfBirth = EmployeeRecord.DateOfBirth;
                _employeeEntity.JMBG = EmployeeRecord.Jmbg;
                _employeeEntity.Address = EmployeeRecord.Address;
                _employeeEntity.Email = EmployeeRecord.Email;
                _employeeEntity.PhoneNumber = EmployeeRecord.PhoneNumber;

                try
                {
                    if (EmployeeRecord.Id <= 0)
                    {
                        _repository.AddEmployee(_employeeEntity);
                        MessageBox.Show("New record successfully saved.");
                        foreach (Window item in Application.Current.Windows)
                        {
                            if (item.DataContext == this) item.Close();
                        }
                    }
                    else
                    {
                        _employeeEntity.ID = EmployeeRecord.Id;
                        _repository.UpdateEmployee(_employeeEntity);
                        MessageBox.Show("Record successfully updated.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occured while saving. " + ex.InnerException);
                }
                finally
                {
                    GetAll();
                    ResetData();
                }
            }
        }

        public void EditData(int id)
        {
            var model = _repository.Get(id);

            EmployeeRecord.Id = model.ID;
            EmployeeRecord.Name = model.Name;
            EmployeeRecord.LastName = model.LastName;
            EmployeeRecord.DateOfBirth = (DateTime)model.DateOfBirth;
            EmployeeRecord.Jmbg = (int)model.JMBG;
            EmployeeRecord.Address = model.Address;
            EmployeeRecord.Email = model.Email;
            EmployeeRecord.PhoneNumber = (int)model.PhoneNumber;
        }

        public void GetAll()
        {
            EmployeeRecord.EmployeeRecords = new ObservableCollection<EmployeeRecord>();
            _repository.GetAll().ForEach(data => EmployeeRecord.EmployeeRecords.Add(new EmployeeRecord()
            {
                Id = data.ID,
                Name = data.Name,
                LastName = data.LastName,
                DateOfBirth = (DateTime)data.DateOfBirth,
                Jmbg = Convert.ToInt32(data.JMBG),
                Address = data.Address,
                Email = data.Email,
                PhoneNumber = Convert.ToInt32(data.PhoneNumber)
            }));
        }


    }
}
