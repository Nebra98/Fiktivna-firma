﻿using Project.Models;
using Project.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Project.Views
{
    /// <summary>
    /// Interaction logic for EditEmployeeView.xaml
    /// </summary>
    public partial class EditEmployeeView : Window
    {
        int Id;
        FirmEntities _db = new FirmEntities();

        public EditEmployeeView(int employeeId)
        {
            InitializeComponent();

            Id = employeeId;
            Employee updateEmployee = (from e in _db.Employees
                                     where e.ID == Id
                                     select e).Single();

            //TextBoxName.Text = updateStudent.Name;


            TextBoxName.Text = updateEmployee.Name;
            TextBoxLastName.Text = updateEmployee.LastName;
            TextBoxDateOfBirth.Text = updateEmployee.DateOfBirth.ToString();
            TextBoxJMBG.Text = updateEmployee.JMBG.ToString();
            TextBoxAddress.Text = updateEmployee.Address;
            TextBoxEmail.Text = updateEmployee.Email;
            TextBoxPhoneNumber.Text = updateEmployee.PhoneNumber.ToString();

            this.DataContext = new EmployeeViewModel();

        }

        private void updateEmployeeBtn_Click(object sender, RoutedEventArgs e)
        {
            Employee updateEmployee = (from E in _db.Employees
                                     where E.ID == Id
                                     select E).Single();
            updateEmployee.Name = TextBoxName.Text;
            updateEmployee.LastName = TextBoxLastName.Text;
            updateEmployee.DateOfBirth = DateTime.Parse(TextBoxDateOfBirth.Text);
            updateEmployee.JMBG = Int32.Parse(TextBoxJMBG.Text);
            updateEmployee.Address = TextBoxAddress.Text;
            updateEmployee.Email = TextBoxEmail.Text;
            updateEmployee.PhoneNumber = Int32.Parse(TextBoxPhoneNumber.Text);


            _db.SaveChanges();
            MessageBox.Show("Record successfully updated.");
            //this.DataContext = new StudentViewModel();

            this.Hide();
        }
    }
}
