﻿using Project.Models;
using Project.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Project.Views
{
    /// <summary>
    /// Interaction logic for EmployeeView.xaml
    /// </summary>
    public partial class EmployeeView : Window
    {

        FirmEntities _db = new FirmEntities();

        public EmployeeView()
        {
            InitializeComponent();
            this.DataContext = new EmployeeViewModel();

        }

        private void insertEmployeeBtn_Click(object sender, RoutedEventArgs e)
        {
            InsertEmployeeView IEPage = new InsertEmployeeView();
            IEPage.ShowDialog();
            IEPage.Activate();
            this.DataContext = new EmployeeViewModel();
        }

        private void updateEmployeeBtn_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                int Id = (DataGridEmployees.SelectedItem as EmployeeRecord).Id;
                EditEmployeeView EEPage = new EditEmployeeView(Id);
                EEPage.ShowDialog();
                EEPage.Activate();
                this.DataContext = new EmployeeViewModel();

            } catch
            {
                MessageBox.Show("You must select an employee to edit");
            }
            


        }

        private void LogOut_Click(object sender, RoutedEventArgs e)
        {
            LoginPage lP = new LoginPage();
            Close();
            lP.Show();

        }

        private void deleteEmployeeBtn_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                EmployeeViewModel em = new EmployeeViewModel();

                int Id = (DataGridEmployees.SelectedItem as EmployeeRecord).Id;
                em.DeleteEmployee(Id);
                this.DataContext = new EmployeeViewModel();

            }
            catch
            {
                MessageBox.Show("You must select an employee to delete");
            }


        }
    }
}
