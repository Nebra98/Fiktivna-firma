﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using System.Data;
using Project.ViewModels;
using Project.Models;

namespace Project.Views
{
    /// <summary>
    /// Interaction logic for LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Window
    {

        FirmEntities _db = new FirmEntities();

        EmployeeView employeeView = new EmployeeView();

        public LoginPage()
        {
            InitializeComponent();
            this.DataContext = new EmployeeViewModel();
        }

        private void loginButton_Click(object sender, RoutedEventArgs e)
        {
            if (textBoxEmail.Text.Length == 0)
            {
                errormessage.Text = "Enter an email.";
                textBoxEmail.Focus();
            }
            else if (!Regex.IsMatch(textBoxEmail.Text, @"^(?=[A-Za-z0-9])(?!.*[._()\[\]-]{2})[A-Za-z0-9._()\[\]-]{3,15}$"))
            {
                errormessage.Text = "Enter a valid email.";
                textBoxEmail.Select(0, textBoxEmail.Text.Length);
                textBoxEmail.Focus();
            }
            else
            {
                string email = textBoxEmail.Text;
                string password = passwordBox1.Password;
                SqlConnection con = new SqlConnection("Data Source=MARKO-GALIC\\SQLEXPRESS;Initial Catalog=Project;User ID=sa;Password=_&cf?mqND4wL");
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from Users where Name='" + email + "'  and Password='" + password + "'", con);
                cmd.CommandType = CommandType.Text;
                SqlDataAdapter adapter = new SqlDataAdapter();
                adapter.SelectCommand = cmd;
                DataSet dataSet = new DataSet();
                adapter.Fill(dataSet);
                if (dataSet.Tables[0].Rows.Count > 0)
                {
                    string username = dataSet.Tables[0].Rows[0]["Name"].ToString();
                    string id = dataSet.Tables[0].Rows[0]["ID"].ToString();
                    employeeView.TextBlockName.Text = username;//Sending value from one form to another form.  
                    employeeView.TextBlockID.Text = id;

                    int user_id = int.Parse(id);

                    Role roles = (from r in _db.Roles
                                  where r.User_id == user_id
                                  select r).Single();

                    if(roles.Write == false)
                    {
                        employeeView.insertEmployeeBtn.IsEnabled = false;
                    }
                    if(roles.Update == false)
                    {
                        employeeView.updateEmployeeBtn.IsEnabled = false;
                    }
                    if (roles.Delete == false)
                    {
                        employeeView.deleteEmployeeBtn.IsEnabled = false;
                    }
                    if (roles.Read == false)
                    {
                        employeeView.DataGridEmployees.Visibility = Visibility.Collapsed;
                        employeeView.updateEmployeeBtn.IsEnabled = false;
                        employeeView.deleteEmployeeBtn.IsEnabled = false;

                    }

                    // employeeView.updateEmployeeBtn.


                    employeeView.Show();
                    
                    Close();
                }
                else
                {
                    errormessage.Text = "Please enter existing emailid/password.";
                }
                con.Close();
            }
        }
    }
}
