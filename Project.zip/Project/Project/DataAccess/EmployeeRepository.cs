﻿using Project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.DataAccess
{
    public class EmployeeRepository
    {

        private FirmEntities employeeContext = null;

        public EmployeeRepository()
        {
            employeeContext = new FirmEntities();
        }

        public Employee Get(int id)
        {
            return employeeContext.Employees.Find(id);
        }

        public List<Employee> GetAll()
        {
            return employeeContext.Employees.ToList();
        }

        public void AddEmployee(Employee employee)
        {
            if (employee != null)
            {
                employeeContext.Employees.Add(employee);
                employeeContext.SaveChanges();
            }
        }

        public void UpdateEmployee(Employee employee)
        {
            var employeeFind = this.Get(employee.ID);

            if(employeeFind != null)
            {
                employeeFind.Name = employee.Name;
                employeeFind.LastName = employee.LastName;
                employeeFind.DateOfBirth = employee.DateOfBirth;
                employeeFind.JMBG = employee.JMBG;
                employeeFind.Address = employee.Address;
                employeeFind.Email = employee.Email;
                employeeFind.PhoneNumber = employee.PhoneNumber;

                employeeContext.SaveChanges();
            }
        }

        public void RemoveEmployee(int id)
        {
            var empObj = employeeContext.Employees.Find(id);
            if(empObj != null)
            {
                employeeContext.Employees.Remove(empObj);
                employeeContext.SaveChanges();
            }
        }


    }
}
